#include "minishell.h"

void	free_tokens(t_mshell *mshell)
{
	t_tkn	*tmp;

	mshell->tkn = mshell->head_tkn;
	while (mshell->tkn)
	{
		free(mshell->tkn->tkn);
		tmp = mshell->tkn;
		mshell->tkn = mshell->tkn->next;
		free(tmp);
	}
}
