#include "minishell.h"

int	unforked_builtin_redir_treat(t_mshell *mshell, int *backup)
{
	backup[0] = -1;
	backup[1] = -1;
	if (mshell->built->builtin_p == -1)
	{
		bckup_stdin_out(backup);
		enable_redirections(mshell);
	}
	return (1);
}

int	re_establish_stdin_out(int *backup)
{
	dup2(backup[0], STDIN_FILENO);
	dup2(backup[1], STDOUT_FILENO);
	close(backup[0]);
	close(backup[1]);
	return (1);
}

int	bckup_stdin_out(int *backup)
{
	backup[0] = dup(STDIN_FILENO);
	backup[1] = dup(STDOUT_FILENO);
	return (1);
}

int	exit_builtin(t_mshell *mshell, int *backup, int exit_code)
{
	if (mshell->built->builtin_p == 1)
	{
		terminate(mshell);
		exit(exit_code);
	}
	close_file_fd(mshell);
	re_establish_stdin_out(backup);
	g_exit = exit_code;
	return (1);
}
