#include "minishell.h"

int	copy_first_cmd_arg(t_mshell *mshell, int *i)
{
	int	i1;

	i1 = 0;
	mshell->execve->cmd_args[*i] = malloc(sizeof(char)
			* (my_strlen(mshell->exec->start_exec->tkn) + 1));
	if (!mshell->execve->cmd_args[*i])
		return (0);
	while (mshell->exec->start_exec->tkn[i1])
	{
		mshell->execve->cmd_args[*i][i1] = mshell->exec->start_exec->tkn[i1];
		i1++;
	}
	mshell->execve->cmd_args[*i][i1] = '\0';
	(*i)++;
	return (1);
}

int	copy_cmd_arg(t_mshell *mshell, int *i)
{
	int	i1;

	i1 = 0;
	mshell->execve->cmd_args[*i] = malloc(sizeof(char)
			* (my_strlen(mshell->exec->start_exec->tkn) + 1));
	if (!mshell->execve->cmd_args[*i])
		return (0);
	while (mshell->exec->start_exec->tkn[i1])
	{
		mshell->execve->cmd_args[*i][i1] = mshell->exec->start_exec->tkn[i1];
		i1++;
	}
	mshell->execve->cmd_args[*i][i1] = '\0';
	(*i)++;
	return (1);
}

int	arg_seeker_execve_args(t_mshell *mshell)
{
	int	i;

	i = 0;
	if (mshell->exec->no_cmd == 1)
		return (0);
	while (mshell->exec->start_exec)
	{
		if (mshell->exec->start_exec->type == _ARG)
			i++;
		mshell->exec->start_exec = mshell->exec->start_exec->next;
	}
	mshell->exec->start_exec = mshell->exec->start_exec_head;
	mshell->execve->cmd_args = malloc(sizeof(char *) * (i + 2));
	if (!mshell->execve->cmd_args)
		return (0);
	mshell->execve->cmd_args[i + 1] = NULL;
	return (1);
}

int	seek_cmd_args(t_mshell *mshell)
{
	int	i;

	i = 0;
	mshell->exec->start_exec = mshell->exec->start_exec_head;
	if (!arg_seeker_execve_args(mshell))
		return (1);
	i = 0;
	set_pos_to_cmd(mshell);
	copy_first_cmd_arg(mshell, &i);
	mshell->exec->start_exec = mshell->exec->start_exec_head;
	while (mshell->exec->start_exec)
	{
		if (mshell->exec->start_exec->type == _ARG)
			copy_cmd_arg(mshell, &i);
		mshell->exec->start_exec = mshell->exec->start_exec->next;
	}
	mshell->exec->start_exec = mshell->exec->start_exec_head;
	return (1);
}
