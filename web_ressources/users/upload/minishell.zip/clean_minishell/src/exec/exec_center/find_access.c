#include "minishell.h"

int	rewind_cmd(t_mshell *mshell)
{
	int	i;

	i = 0;
	while (mshell->exec->start_exec->tkn[i])
		i++;
	mshell->execve->cmd = malloc(sizeof(char) * (i + 1));
	if (!mshell->execve->cmd)
		return (0);
	i = 0;
	while (mshell->exec->start_exec->tkn[i])
	{
		mshell->execve->cmd[i] = mshell->exec->start_exec->tkn[i];
		i++;
	}
	mshell->execve->cmd[i] = '\0';
	return (1);
}

int	join_path_to_tmp_command__exec_access(t_mshell *mshell,
	char **cmd_tmp, int j, int *i)
{
	int	a;

	a = 0;
	while (mshell->execve->paths[*i][a])
	{
		(*cmd_tmp)[j] = mshell->execve->paths[*i][a];
		a++;
		j++;
	}
	a = 0;
	while (mshell->exec->start_exec->tkn[a])
	{
		(*cmd_tmp)[j] = mshell->exec->start_exec->tkn[a];
		a++;
		j++;
	}
	(*cmd_tmp)[j] = '\0';
	return (1);
}

int	join_cmd_for_access(t_mshell *mshell, int *i)
{
	char	*cmd_tmp;
	int		a;
	int		j;

	a = my_strlen(mshell->execve->paths[*i]);
	j = my_strlen(mshell->exec->start_exec->tkn);
	cmd_tmp = malloc(sizeof(char) * (a + j + 1));
	if (!cmd_tmp)
		return (0);
	a = 0;
	j = 0;
	join_path_to_tmp_command__exec_access(mshell, &cmd_tmp, j, i);
	mshell->execve->cmd = cmd_tmp;
	return (1);
}

int	find_access(t_mshell *mshell)
{
	int		i;
	int		a;

	i = 0;
	if (mshell->exec->no_cmd == 1 || mshell->exec->start_exec->type != _CMD)
		return (1);
	set_pos_to_cmd(mshell);
	while (mshell->execve->paths[i])
	{
		join_cmd_for_access(mshell, &i);
		a = access(mshell->execve->cmd, X_OK | F_OK);
		if (!a)
			return (mshell->exec->start_exec
				= mshell->exec->start_exec_head, 1);
		free(mshell->execve->cmd);
		mshell->execve->cmd = NULL;
		i++;
	}
	rewind_cmd(mshell);
	mshell->exec->start_exec = mshell->exec->start_exec_head;
	return (0);
}
