#include "minishell.h"

void	exit_process(int err, char *tkn, t_mshell *mshell)
{
	cmd_err_message(mshell->exec->start_exec->tkn);
	if (mshell->exec->no_redirs != -1)
		close_file_fd(mshell);
	terminate(mshell);
	if (err == ENOENT)
		exit(127);
	exit (1);
	(void)tkn;
}

int	close_file_fd(t_mshell *mshell)
{
	if (mshell->exec->fd)
	{
		while (mshell->exec->n_fd > 0)
		{
			close(mshell->exec->fd[mshell->exec->n_fd - 1]);
			mshell->exec->n_fd--;
		}
	}
	return (1);
}

int	no_cmd_no_pipe(t_mshell *mshell, int *backup)
{
	bckup_stdin_out(backup);
	enable_redirections(mshell);
	close_file_fd(mshell);
	re_establish_stdin_out(backup);
	close(backup[0]);
	close(backup[1]);
	return (1);
}

int	unforked(t_mshell *mshell, int *backup)
{
	if (!mshell->exec->next && scan_builtin(mshell))
		return (0);
	if (!mshell->exec->next && mshell->exec && mshell->exec->no_cmd == 1)
		return (no_cmd_no_pipe(mshell, backup), 0);
	return (1);
}

int	start_exec(t_mshell *mshell, int *backup)
{
	backup[0] = -1;
	backup[1] = -1;
	mshell->pipe_fd[0] = -1;
	mshell->built->builtin_p = -1;
	if (!init_exec(mshell))
		return (0);
	if (!build_commands_chains(mshell))
		return (0);
	return (1);
}
