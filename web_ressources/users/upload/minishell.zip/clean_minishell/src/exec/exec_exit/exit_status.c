#include "minishell.h"

char	*exit_status(t_mshell *mshell)
{
	return (my_itoa(g_exit));
	(void)mshell;
}
