#include "minishell.h"

int	check_expander(t_mshell *mshell)
{
	t_expt	*head;

	head = mshell->expt;
	mshell->expd->old_expd_len = my_strlen(mshell->expd->expander);
	while (mshell->expt->next)
	{
		if (!my_strcmp(mshell->expd->expander, mshell->expt->exptvar))
		{
			make_expansion(mshell, mshell->expt->value);
			mshell->expd->new_expd_len = my_strlen(mshell->expd->expander);
			mshell->expt = head;
			return (1);
		}
		mshell->expt = mshell->expt->next;
	}
	if (mshell->expd->expander)
		free(mshell->expd->expander);
	mshell->expd->expander = NULL;
	mshell->expd->new_expd_len = 0;
	mshell->expt = head;
	return (1);
}
