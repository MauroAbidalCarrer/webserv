#include "minishell.h"

int	make_expansion(t_mshell *mshell, char *input)
{
	int	len;
	int	i;

	i = 0;
	len = my_strlen(input);
	if (mshell->expd->expander)
		free(mshell->expd->expander);
	if (!len)
		return (0);
	mshell->expd->expander = malloc(sizeof(char) * (len + 1));
	if (!mshell->expd->expander)
		return (0);
	while (input[i])
	{
		mshell->expd->expander[i] = input[i];
		i++;
	}
	mshell->expd->expander[i] = '\0';
	return (1);
}
