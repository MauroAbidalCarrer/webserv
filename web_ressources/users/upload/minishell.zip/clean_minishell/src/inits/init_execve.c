#include "minishell.h"

int	init_execve(t_mshell *mshell, char **env)
{
	mshell->execve = malloc(sizeof(t_execve));
	if (!mshell->execve)
		return (0);
	mshell->execve->cmd = NULL;
	mshell->execve->cmd_args = NULL;
	mshell->execve->paths = NULL;
	if (!*env)
		return (1);
	parse_paths(mshell);
	return (1);
}
