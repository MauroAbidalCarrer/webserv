#include "minishell.h"

int	init_t_token(t_mshell *mshell)
{
	mshell->tkn = malloc(sizeof(t_tkn));
	if (!mshell->tkn)
		return (0);
	mshell->tkn->type = -1;
	mshell->tkn->tkn = NULL;
	mshell->tkn->pipe_fd_hrdoc[0] = -1;
	mshell->tkn->pipe_fd_hrdoc[1] = -1;
	mshell->tkn->next = NULL;
	mshell->head_tkn = mshell->tkn;
	return (1);
}
