#include "minishell.h"

int	init_exec(t_mshell *mshell)
{
	mshell->exec = malloc(sizeof(t_exec));
	if (!mshell->exec)
		return (0);
	mshell->exec->fd = NULL;
	mshell->exec->fd_in = 0;
	mshell->exec->n_fd = -1;
	mshell->exec->fd_out = 1;
	mshell->exec->no_cmd = -1;
	mshell->exec->no_redirs = -1;
	mshell->exec->p_listener = -1;
	mshell->exec->start_exec = NULL;
	mshell->exec->start_exec_head = NULL;
	mshell->head_exec = mshell->exec;
	mshell->exec->next = NULL;
	return (1);
}
