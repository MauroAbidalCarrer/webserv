#include "minishell.h"

int	begin_command(t_mshell *mshell, char **env)
{
	if (*env)
	{
		if (!dup_env(&mshell->env, env, &mshell->envc))
			return (0);
		if (!sort_export(mshell))
			return (0);
		mshell->exec_env = copy_env_in_tab(mshell);
		if (!mshell->exec_env)
			return (0);
		mshell->head_env = mshell->env;
		mshell->head_expt = mshell->expt;
	}
	else
	{
		set_default_env(mshell);
		set_default_export(mshell);
		mshell->exec_env = copy_env_in_tab(mshell);
		if (!mshell->exec_env)
			return (0);
		mshell->head_env = mshell->env;
		mshell->head_expt = mshell->expt;
	}
	return (1);
}

t_mshell	*init_mshell(char **env)
{
	t_mshell	*mshell;

	mshell = malloc(sizeof(t_mshell));
	if (!mshell)
		return (NULL);
	mshell->env = NULL;
	mshell->tkn = NULL;
	mshell->expt = NULL;
	mshell->expd = NULL;
	mshell->exec = NULL;
	mshell->execve = NULL;
	mshell->no_env = 10;
	mshell->empty_cmd = 0;
	mshell->exit_status = 0;
	mshell->exec_env = NULL;
	mshell->pipe_fd[0] = -1;
	mshell->pipe_fd[1] = -1;
	mshell->dup_heredoc = -1;
	mshell->old_expd__hrdoc = -1;
	if (!begin_command(mshell, env))
		return (NULL);
	return (mshell);
}
