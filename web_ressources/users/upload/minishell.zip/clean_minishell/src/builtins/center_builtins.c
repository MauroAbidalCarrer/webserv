#include "minishell.h"

int	center_builtins(t_mshell *mshell, int type)
{
	(void)mshell;
	(void)type;
	return (1);
}
