#include "minishell.h"

int	do_pwd(t_mshell *mshell)
{
	char	path[1024];

	if (!getcwd(path, 1024))
	{
		g_exit = 1;
		return (0);
	}
	my_putstr(path);
	my_putchar('\n');
	g_exit = 0;
	(void)mshell;
	return (1);
}
