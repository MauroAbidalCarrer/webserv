#include "minishell.h"

int	declare_export(t_mshell *mshell)
{
	t_expt	*head;

	head = mshell->expt;
	while (mshell->expt->next)
	{
		my_putstr_fd(1, "declare -x ");
		my_putstr_fd(1, mshell->expt->exptvar);
		if (mshell->expt->value)
		{
			my_putstr_fd(1, "=");
			my_putstr_fd(1, mshell->expt->value);
		}
		my_putstr_fd(1, "\n");
		mshell->expt = mshell->expt->next;
	}
	mshell->expt = head;
	return (1);
}

void	print_env(t_mshell *mshell)
{
	t_env	*env;

	env = mshell->env;
	while (env)
	{
		my_putstr(env->envar);
		my_putchar('=');
		if (env->value)
		{
			my_putstr(env->value);
		}
		my_putchar('\n');
		env = env->next;
	}
}

int	do_env(t_mshell *mshell)
{
	int		backup[2];

	backup[0] = -1;
	backup[1] = -1;
	if (mshell->built->builtin_p == -1)
	{
		bckup_stdin_out(backup);
		enable_redirections(mshell);
	}
	print_env(mshell);
	if (mshell->exec->no_redirs != -1)
		close_file_fd(mshell);
	if (mshell->built->builtin_p == 1)
	{
		if (mshell->exec->next)
			close_pipe_fds(mshell);
		terminate(mshell);
		exit(0);
	}
	re_establish_stdin_out(backup);
	g_exit = 0;
	return (1);
}
