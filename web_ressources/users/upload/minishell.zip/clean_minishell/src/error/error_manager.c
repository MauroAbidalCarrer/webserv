#include "minishell.h"

int	export_numeric_error(t_mshell *mshell)
{
	my_putstr_fd(2, "minishell: export: `");
	my_putstr_fd(2, mshell->built->export_var);
	my_putstr_fd(2, "': not a valid identifier\n");
	return (1);
}

int	error_manager(char *process, char *tkn, char *error)
{
	my_putstr("minishell: ");
	my_putstr(process);
	if (tkn)
	{
		my_putstr(": `");
		my_putstr(tkn);
		my_putstr("': ");
	}
	else
		my_putstr(": ");
	my_putstr(error);
	my_putchar('\n');
	return (1);
}

void	cmd_err_message(char *cmd)
{
	if (!my_strlen(cmd))
		my_putstr_fd(2, "minishell: : command not found\n");
	else
	{
		my_putstr_fd(2, "minishell: ");
		my_putstr_fd(2, cmd);
		my_putstr_fd(2, ": command not found\n");
	}
}

int	open_error(t_mshell *mshell)
{
	my_putstr_fd(2, "minishell: ");
	my_putstr_fd(2, mshell->exec->start_exec->next->tkn);
	my_putstr_fd(2, ": ");
	my_putstr_fd(2, strerror(errno));
	my_putstr_fd(2, "\n");
	return (1);
}
