#include "minishell.h"

void	syntax_error(char *tkn)
{
	my_putstr_fd(2, "minishell: syntax error near unexpected token`");
	if (tkn)
		my_putstr_fd(2, tkn);
	else
		my_putstr_fd(2, "newline");
	my_putstr_fd(2, "'.\n");
}
