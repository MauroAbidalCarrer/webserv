#include "minishell.h"

int	treat_pipe(t_mshell *mshell, int *i)
{
	int	tmp_i;

	tmp_i = *i;
	++(*i);
	mshell->tkn->type = PIPE;
	if (!tokenizer(mshell, tmp_i, *i))
		return (0);
	return (1);
}
