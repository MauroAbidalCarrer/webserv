#include "minishell.h"

int	treat_space(t_mshell *mshell, int *i)
{
	while (mshell->rdline_outp[*i] == ' '
		|| mshell->rdline_outp[*i] == '\n'
		|| mshell->rdline_outp[*i] == '\t'
		|| mshell->rdline_outp[*i] == '\v'
		|| mshell->rdline_outp[*i] == '\f'
		|| mshell->rdline_outp[*i] == '\r')
		++(*i);
	return (1);
}
