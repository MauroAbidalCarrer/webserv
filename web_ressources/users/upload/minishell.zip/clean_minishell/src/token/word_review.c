#include "minishell.h"

void	word_review(t_mshell *mshell, int *cmd_cnt)
{
	if (mshell->tkn->type == WORD)
	{
		if (mshell->tkn == mshell->head_tkn || *cmd_cnt == 0)
		{
			mshell->tkn->type = _CMD;
			*cmd_cnt = 1;
		}
		else
			mshell->tkn->type = _ARG;
	}
}
