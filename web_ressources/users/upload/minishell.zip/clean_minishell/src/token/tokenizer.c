#include "minishell.h"

int	make_new_token(t_mshell *mshell)
{
	mshell->tkn->next = malloc(sizeof(t_tkn));
	if (!mshell->tkn->next)
		return (0);
	mshell->tkn = mshell->tkn->next;
	mshell->tkn->pipe_fd_hrdoc[0] = -1;
	mshell->tkn->pipe_fd_hrdoc[1] = -1;
	mshell->tkn->tkn = NULL;
	mshell->tkn->type = -1;
	mshell->tkn->next = NULL;
	return (1);
}

int	tokenizer(t_mshell *mshell, int strt, int end)
{
	int	i;

	i = -1;
	mshell->tkn->tkn = malloc(sizeof(char) * ((end - strt) + 1));
	if (!mshell->tkn->tkn)
		return (0);
	while (strt < end)
	{
		mshell->tkn->tkn[++i] = mshell->rdline_outp[strt];
		strt++;
	}
	mshell->tkn->tkn[++i] = '\0';
	if (!make_new_token(mshell))
		return (0);
	return (1);
}
