#include "minishell.h"

int	my_isalnum(int c)
{
	if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z')
		|| (c >= '0' && c <= '9'))
		return (1);
	else
		return (0);
}

int	my_isalpha(int c)
{
	if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z'))
		return (1);
	else
		return (0);
}

char	*my_strchr(char *s, int c)
{
	int	i;

	i = 0;
	while (s[i])
	{
		if (((unsigned char *)s)[i] == (unsigned char)c)
			return ((char *)&s[i]);
		i++;
	}
	if (c == 0)
		return (((char *)&s[i]));
	return (NULL);
}

int	search_lowest(char *val, t_env *env)
{
	t_env	*head;
	int		cmp;

	head = env;
	while (env->next)
	{
		cmp = my_strcmp(val, env->envar);
		if (cmp > 0)
			return (env = head, 0);
		env = env->next;
	}
	env = head;
	return (1);
}

char	*my_strdup(char *str)
{
	size_t	i;
	char	*s;
	size_t	size;

	i = 0;
	size = my_strlen(str) + 1;
	s = malloc(size * sizeof(char));
	if (!s)
		return (NULL);
	while (i < size -1)
	{
		s[i] = str[i];
		i++;
	}
	s[i] = '\0';
	return (s);
}
