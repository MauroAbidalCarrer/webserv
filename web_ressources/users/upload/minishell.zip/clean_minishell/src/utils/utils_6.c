#include "minishell.h"

void	my_putchar(char c)
{
	write(1, &c, 1);
}

int	set_pos_to_cmd(t_mshell *mshell)
{
	if (mshell->exec->start_exec->type != -1)
	{
		while (mshell->exec->start_exec && \
		mshell->exec->start_exec->type != _CMD)
		{
			if (!mshell->exec->start_exec->next)
				return (mshell->exec->no_cmd = 1, \
				mshell->exec->start_exec = mshell->exec->start_exec_head, 0);
			mshell->exec->start_exec = mshell->exec->start_exec->next;
		}
	}
	return (1);
}

void	my_putstr(char *str)
{
	int	i;

	i = -1;
	while (str[++i])
		my_putchar(str[i]);
}
